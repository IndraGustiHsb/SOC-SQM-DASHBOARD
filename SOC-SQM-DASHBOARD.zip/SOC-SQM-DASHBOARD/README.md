# SOC-SQM-DASHBOARD

Web dashboard untuk monitoring SQM dengan mode:

- 15 Minutes
- Hourly
- Daily

Filter:
- Date From / Date To
- Branch
- Kabupaten

Metric:
- Total Traffic
- Downlink TCP Retransmission Rate
- Uplink TCP Retransmission Rate
- TCP Connection Success Rate (Included RST)
- Downlink TCP Packet Loss Rate
- Uplink TCP Packet Loss Rate
- E2E Delay
- SYN ACK-ACK Delay
- SYN-SYN ACK Delay

## GitHub Pages

1. Upload `index.html`, `style.css`, `app.js`, dan folder `data`.
2. Pastikan `data/raw_data.csv` berada tepat di dalam folder `data`.
3. Settings → Pages → Deploy from branch → `main` → `/ (root)`.
4. Buka URL GitHub Pages repository.

## Catatan traffic

File sumber menggunakan kolom `Total Traffic(Byte)`. Dashboard menampilkan nilainya sebagai TB sesuai desain yang disepakati dan tidak melakukan konversi otomatis. Jika definisi satuan sumber ternyata berbeda, ubah `TRAFFIC_UNIT` dan `TRAFFIC_SCALE` di `app.js`.
